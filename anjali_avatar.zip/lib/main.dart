import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

enum AvatarBehavior { idle, listening, smile, sad, concern, shy, softAnger }

extension AvatarBehaviorX on AvatarBehavior {
  String get asset {
    switch (this) {
      case AvatarBehavior.idle:
        return 'assets/idle_1a.mp4';
      case AvatarBehavior.listening:
        return 'assets/listening_2a.mp4';
      case AvatarBehavior.smile:
        return 'assets/smile_3a.mp4';
      case AvatarBehavior.sad:
        return 'assets/sad_4a.mp4';
      case AvatarBehavior.concern:
        return 'assets/concern_5a.mp4';
      case AvatarBehavior.shy:
        return 'assets/shy_6a.mp4';
      case AvatarBehavior.softAnger:
        return 'assets/soft_anger_7a.mp4';
    }
  }

  bool get loops =>
      this == AvatarBehavior.idle || this == AvatarBehavior.listening;

  String get label {
    switch (this) {
      case AvatarBehavior.idle:
        return 'Idle';
      case AvatarBehavior.listening:
        return 'Listening';
      case AvatarBehavior.smile:
        return 'Smile';
      case AvatarBehavior.sad:
        return 'Sad';
      case AvatarBehavior.concern:
        return 'Concern';
      case AvatarBehavior.shy:
        return 'Shy';
      case AvatarBehavior.softAnger:
        return 'Anger';
    }
  }
}

class AvatarDirector extends ChangeNotifier {
  AvatarDirector({this.fade = const Duration(milliseconds: 120)});

  final Duration fade;

  VideoPlayerController? _idle;
  final List<VideoPlayerController?> _slot = [null, null];
  final List<double> _opacity = [0, 0];
  final List<Duration> _dur = [Duration.zero, Duration.zero];

  int _upper = 1;
  int _visible = -1;
  int _token = 0;
  bool _ready = false;
  bool _disposed = false;
  AvatarBehavior _current = AvatarBehavior.idle;

  String? error;

  AvatarBehavior get current => _current;
  bool get ready => _ready;
  VideoPlayerController? get idleController => _idle;
  VideoPlayerController? slotController(int i) => _slot[i];
  double opacity(int i) => _opacity[i];
  Duration duration(int i) => _dur[i];
  int get upper => _upper;

  /// Restarts a looping clip by hand if the platform stops it at the end.
  void _guardLoop(VideoPlayerController c) {
    bool busy = false;
    c.addListener(() async {
      if (busy || _disposed) return;
      final v = c.value;
      if (!v.isInitialized || v.duration == Duration.zero) return;
      final atEnd = v.position >= v.duration - const Duration(milliseconds: 150);
      if (!v.isPlaying && atEnd) {
        busy = true;
        try {
          await c.seekTo(Duration.zero);
          await c.play();
        } catch (_) {}
        busy = false;
      }
    });
  }

  Future<void> init() async {
    try {
      final c = VideoPlayerController.asset(AvatarBehavior.idle.asset);
      await c.initialize();
      if (_disposed) {
        await c.dispose();
        return;
      }
      await c.setVolume(0);
      await c.setLooping(true);
      await c.play();
      _guardLoop(c);
      _idle = c;
      _ready = true;
    } catch (e) {
      error = 'Idle load failed:\n$e';
    }
    _safeNotify();
  }

  Future<void> setBehavior(AvatarBehavior b) async {
    if (!_ready || _disposed) return;
    if (b == _current && b.loops) return;

    final token = ++_token;

    if (b == AvatarBehavior.idle) {
      await _returnToIdle(token);
      return;
    }

    final incoming = 1 - _upper;
    final old = _visible;
    final oldCtrl = old == -1 ? null : _slot[old];

    await _disposeSlot(incoming);

    final ctrl = VideoPlayerController.asset(b.asset);
    _slot[incoming] = ctrl;

    try {
      await ctrl.initialize();
      if (_stale(token)) return _abort(incoming, ctrl);

      await ctrl.setVolume(0);
      await ctrl.setLooping(b.loops);
      await ctrl.seekTo(Duration.zero);
      await ctrl.play();
      await Future<void>.delayed(const Duration(milliseconds: 80));
      if (_stale(token)) return _abort(incoming, ctrl);
    } catch (e) {
      error = '${b.asset}\n$e';
      _safeNotify();
      return _abort(incoming, ctrl);
    }

    _current = b;
    _upper = incoming;
    _visible = incoming;
    _dur[incoming] = fade;
    _opacity[incoming] = 1;
    _safeNotify();

    if (b.loops) {
      _guardLoop(ctrl);
    } else {
      ctrl.addListener(() => _watchEnd(ctrl, token));
    }

    await Future<void>.delayed(fade + const Duration(milliseconds: 30));
    if (_disposed) return;

    if (old != -1 && oldCtrl != null && identical(_slot[old], oldCtrl)) {
      _dur[old] = Duration.zero;
      _opacity[old] = 0;
      await _disposeSlot(old);
    }
  }

  void _watchEnd(VideoPlayerController c, int token) {
    if (_disposed || token != _token) return;
    final v = c.value;
    if (!v.isInitialized || v.duration == Duration.zero) return;
    final cutoff = v.duration - fade - const Duration(milliseconds: 80);
    if (v.position >= cutoff) {
      setBehavior(AvatarBehavior.idle);
    }
  }

  Future<void> _returnToIdle(int token) async {
    final vis = _visible;
    _current = AvatarBehavior.idle;
    _visible = -1;
    if (vis == -1) {
      _safeNotify();
      return;
    }

    // Idle ko shuru se chalao, taaki uski pose clip ke aakhir se match kare.
    try {
      await _idle?.seekTo(Duration.zero);
      await _idle?.play();
    } catch (_) {}

    final c = _slot[vis];
    _dur[vis] = fade;
    _opacity[vis] = 0;
    _safeNotify();

    await Future<void>.delayed(fade + const Duration(milliseconds: 40));
    if (_disposed) return;
    if (c != null && identical(_slot[vis], c) && _visible != vis) {
      await _disposeSlot(vis);
    }
  }

  bool _stale(int token) => _disposed || token != _token;

  Future<void> _abort(int slot, VideoPlayerController ctrl) async {
    if (identical(_slot[slot], ctrl)) {
      await _disposeSlot(slot);
    } else {
      try {
        await ctrl.dispose();
      } catch (_) {}
    }
  }

  Future<void> _disposeSlot(int i) async {
    final c = _slot[i];
    if (c == null) return;
    _slot[i] = null;
    _opacity[i] = 0;
    _dur[i] = Duration.zero;
    _safeNotify();
    await WidgetsBinding.instance.endOfFrame;
    try {
      await c.pause();
    } catch (_) {}
    try {
      await c.dispose();
    } catch (_) {}
  }

  void _safeNotify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _token++;
    _idle?.dispose();
    for (final c in _slot) {
      c?.dispose();
    }
    super.dispose();
  }
}

class AvatarView extends StatelessWidget {
  const AvatarView({super.key, required this.director});

  final AvatarDirector director;

  Widget _video(VideoPlayerController c) {
    return FittedBox(
      fit: BoxFit.cover,
      clipBehavior: Clip.hardEdge,
      child: SizedBox(
        width: c.value.size.width,
        height: c.value.size.height,
        child: VideoPlayer(c),
      ),
    );
  }

  Widget _overlay(int i) {
    final c = director.slotController(i);
    if (c == null || !c.value.isInitialized) return const SizedBox.shrink();
    return Positioned.fill(
      child: AnimatedOpacity(
        opacity: director.opacity(i),
        duration: director.duration(i),
        child: _video(c),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: director,
      builder: (context, _) {
        final idle = director.idleController;
        final lower = 1 - director.upper;
        return Stack(
          fit: StackFit.expand,
          children: [
            const ColoredBox(color: Colors.black),
            if (idle != null && idle.value.isInitialized)
              Positioned.fill(child: _video(idle)),
            _overlay(lower),
            _overlay(director.upper),
            if (director.error != null)
              Positioned(
                top: 40,
                left: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  color: Colors.black87,
                  child: Text(
                    director.error!,
                    style: const TextStyle(
                        color: Colors.redAccent, fontSize: 12),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const AnjaliApp());
}

class AnjaliApp extends StatelessWidget {
  const AnjaliApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const AvatarScreen(),
    );
  }
}

class AvatarScreen extends StatefulWidget {
  const AvatarScreen({super.key});

  @override
  State<AvatarScreen> createState() => _AvatarScreenState();
}

class _AvatarScreenState extends State<AvatarScreen> {
  final AvatarDirector _director = AvatarDirector();

  @override
  void initState() {
    super.initState();
    _director.init();
  }

  @override
  void dispose() {
    _director.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(child: AvatarView(director: _director)),
          Align(
            alignment: Alignment.bottomCenter,
            child: SafeArea(
              child: Container(
                height: 64,
                color: Colors.black54,
                child: AnimatedBuilder(
                  animation: _director,
                  builder: (context, _) {
                    return ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 10),
                      children: [
                        for (final b in AvatarBehavior.values)
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _director.current == b
                                    ? Colors.amber
                                    : Colors.grey.shade800,
                                foregroundColor: _director.current == b
                                    ? Colors.black
                                    : Colors.white,
                              ),
                              onPressed: () => _director.setBehavior(b),
                              child: Text(b.label),
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}